<?php

$menu = array(
    0=>array(
    'name'=>'Home',
    'link'=>'index.php'
        ),
    1=>array(
        'name'=>'Create a Task',
        'link'=>'create.php'
    ),
    2=>array(
        'name'=>'Your Tasks',
        'link'=>'index.php?page=tasks&action=list'
    )
   
);

