<?php

$priorities = array(0=>'Low',1=>'High', 2=>'Medium');