<?php

if (!isset($_SESSION['user_id'])) {
       header('Location: index.php?page=user&action=login');   
}
if (isset($_SERVER['REQUEST_METHOD']) == 'POST' && isset($_POST['createTask'])) {
    
    $createTask = Task::createTask($_POST['title'], $_POST['description'], $_POST['created']);
    
    if (is_array($createTask)) {
        foreach ($createTask as $error) {
           echo '<pre>' . print_r($error, true) . '</pre>';
        }
    }else{
          header('Location: index.php?page=tasks&action=list');
    }
}