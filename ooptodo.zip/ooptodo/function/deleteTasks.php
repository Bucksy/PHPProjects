<?php
if (isset($_SERVER['REQUEST_METHOD']) === 'GET' && isset($_GET['id'])) {
    $idTask = $_GET['id'];
    $deletedUser = Task::deleteTask($idTask);
    if (is_array($deletedUser)) {
        foreach ($deletedUser as $error) {
            echo '<pre>' . print_r($error, true) . '</pre>';
        }
    }else{
        header('Location: index.php?page=tasks&action=list');
    }
}