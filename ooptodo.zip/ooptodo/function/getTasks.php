<?php
session_start();
include './lib/User.php';
include './lib/Task.php';

//exit(var_dump($_SESSION));

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $tasks = Task::getTasks($_SESSION['user_id']);//null ? or array , if tasks return null value, then show the messages !
    //exit(var_dump($tasks['data']));
    
    if (in_array('errorMessage', $tasks)) {
        foreach ($tasks['data'] as $error) {
            echo '<pre>' . print_r($error, true) . '</pre>'; 
        }
    }else{
        echo '<pre>' . print_r($tasks, true) . '</pre>';
    }
}
