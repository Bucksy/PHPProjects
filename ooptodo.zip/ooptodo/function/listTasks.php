<?php
//session_start();
//include './lib/User.php';
//include './lib/Task.php';
//exit(var_dump($_SESSION));

if ($_SERVER['REQUEST_METHOD'] == 'GET') {

    $tasks = Task::getTasks($_SESSION['user_id']); //null ? or array , if tasks return null value, then show the messages !

    if (in_array('errorMessage', $tasks)) {
        foreach ($tasks['data'] as $error) {
            echo '<pre>' . print_r($error, true) . '</pre>';
        }
    } else {
        ?>
        <div id="tasks">
            <table border="1px">
                <tr>
                    <td>Title</td>
                    <td>Description</td>
                    <td>Created</td>
                    <td colspan="2">Actions</td>
                </tr>
                
                <?php
                foreach ($tasks as $task) {
                    echo ' <tr><td>' . $task->title . '</td>' .
                               '<td>' . $task->description . '</td>
                             <td>' . $task->created . '</td>'.
                            '<td><a href="index.php?page=tasks&action=update&id='.$task->id.'">Update</a></td>'.
                            '<td><a href="index.php?page=tasks&action=delete&id='.$task->id.'">Delete</a></td>'
                        . '</tr>';
                }
                ?>
            </table>
        </div>
        <?php
    }
}
