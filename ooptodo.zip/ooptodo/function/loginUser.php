<a href="index.php?page=password&action=update">Update Password</a> 
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' || isset($_POST['submitLogin'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $user = User::loginUser($email, $password);
//        exit(var_dump($user));
    if (is_array($user)) {
        foreach ($user as $value) {
            echo $value;
        }
    } else {
        header('Location: index.php?page=tasks&action=list');
    }
}