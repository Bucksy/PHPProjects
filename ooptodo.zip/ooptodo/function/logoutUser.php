<?php

$user = User::logoutUser($_SESSION['user_id']);
