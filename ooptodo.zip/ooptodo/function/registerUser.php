<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['registerSubmit'])) {
    
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmPass = $_POST['confirmPassword'];
    
    $registerUser = User::registerUser($username, $email, $password, $confirmPass);
   // echo '<pre>' . print_r($registerUser[0], true) . '</pre>';
    if (is_array($registerUser)) {
        foreach ($registerUser as $value) {
            if (!is_array($value)) {
                $value = array($value);
            }
            echo '<pre>' . print_r($value[0], true) . '</pre>';
        }
    }else{
//        echo 'Successfully registered';
//        echo $registerUser->username;
        //echo $registerUser->username;
        header('Location: index.php?page=user&action=login');
    }
}