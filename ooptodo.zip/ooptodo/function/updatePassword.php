<?php

if (!isset($_SESSION['logged'])) {
    // exit(var_dump($_SESSION['user_id']));
    header('Location: index.php?page=user&action=login');
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' || isset($_POST['passwordSubmit'])) {
    $updated = User::updatePassword($_POST['email'], $_POST['password'], $_POST['newPassword'], $_POST['confirmPassword']);
    //exit(var_dump($updated));
    if (is_array($updated)) {
        foreach ($updated as $value) {
            echo '<pre>' . print_r($value[0], true) . '</pre>';
        }
    } else {
        //exit(var_dump($updated));
        header('Location: index.php?page=user&action=login');
    }
}