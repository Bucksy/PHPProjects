<?php

if (!isset($_SESSION['logged'])) {
    header('Location: index.php?page=user&action=login');
}else if (isset($_SERVER['REQUEST_METHOD']) === 'GET' && isset($_GET['id'])) {
   
    $idTask = $_GET['id'];
    $task = Task::getTask($idTask); 
    //exit(var_dump($task));
}else if (isset($_SERVER['REQUEST_METHOD']) === 'POST') {
    
    $idTask = $_GET['id'];
    $task = Task::getTask($idTask);
    $updateTask  = $task->updateTask($_POST['title'], $_POST['description'], $_POST['created']);
    header('Location: index.php?page=tasks&action=list');
}