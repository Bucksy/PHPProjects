<?php
include './lib/Task.php';

$task = Task::getTask($_GET['id']);
echo '<pre>' . print_r($task, true) . '</pre>';
//if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
//    $task = Task::getTask($_GET['id']);
//    //exit(var_dump($task));
//    if (is_array($task)) {
//        foreach ($task as $error) {
//            echo "<p>$error</p>";
//        }
//    }else{
//        echo '<pre>' . print_r($task, true) . '</pre>';
//    }
//}else{
//    echo 'error';
//}

