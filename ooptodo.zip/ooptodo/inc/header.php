
<?php
mb_internal_encoding('UTF-8');
session_start(); 
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title><?= $title;?></title>
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>
    <body>
        