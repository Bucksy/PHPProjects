<?php
$title = 'Create your own task';
include './inc/header.php';
include './data/data.php';
include './lib/DispatcherRequest.php';
include './lib/Task.php';
include './lib/User.php';
?>
<div id="container">
    <div class="top">
        <div class="logo">

        </div>
        <div class="menu">
            <?php foreach ($menu as $item): ?>
                <ul>
                    <li><a href="<?= $item['link'] ?>"><?= $item['name'] ?></a></li>
                </ul>
            <?php endforeach; ?> 
            <div class="greeting">
                <a href="index.php?page=user&action=login">Log in</a>
                <a href="index.php?page=user&action=logout">Log out</a>
                <a href="index.php?page=user&action=register">Register</a>
            </div>
        </div>
    </div>
    <div class="body">
        <?php
        if (isset($_GET['page'])) {
            echo 'Folder : '.$_GET['page'];
            echo '<br/>';
            DispatcherRequest::processRequest($_GET['action'], $_GET['page'], 'function');
        }
        ?> 
    </div>
</div>
<?php
include './inc/footer.php';
