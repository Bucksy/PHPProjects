<?php

class DispatcherRequest{
    
    private $defaultAction = 'login';
    private $defaultPage = 'user';  
    private static $viewNotRequired = array('delete', 'logout');
    private static $test = array('password');
    
    public static function processRequest($action, $page, $function) { //get['action'] = list , get['page'] = tasks 
        
        if (isset($action)) {
            $view = "$page/$action"; //tasks/list.php
            $function = "$function/". $action . ucfirst($page);//function/listTasks.php
            echo ' View: ' . $view.'.php';
            echo '<br/>';
            echo ' Function : /' . $function.'.php';
            echo '<br/>';
        } else {
            $view = $this->defaultPage . '/' . $this->defaultAction; //
            $function = "$function/". $this->defaultAction . ucfirst($this->defaultPage);
            echo '<br/>';
            echo 'View: ' . $view.'.php';
            echo '<br/>';
            echo 'Function : /' . $function.'.php';
        }
        
        include "$function.php";
        
        if (!in_array($action, self::$viewNotRequired)) {//tezi koito ne sa v tozi spisuk , includevame viewto , inache includni kakto vinagi 
            if (in_array($page, self::$test)) {
                $page = 'user';
                $view = "$page/$action";
                include "$view.php";
            } else { 
                include "$view.php"; //drug view
            }
        }

        //include "$function.php";
       
    }
}
