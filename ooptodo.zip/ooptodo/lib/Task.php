<?php

include './lib/Validation.php';


class Task {
    
    private $id;
    public $title,
            $description,
            $created,
            $userId;
    //crud
    public static function getTask($idTask) { //One task
        //SESSION
        //VALIDATION
        $errors = array();
        $idValidation = Validation::validateRequired($idTask, 'Id Task'); //masiv veche tuka shtom sme promenili  idTask - > toi veche e masiv, a ne id prosto 
        $idTask = (int) $idTask;
        
        if (in_array('error', $idValidation)) {
            $errors = $idValidation['data'];
            //exit(var_dump($idTask));
        } else {
            
            $connection = new mysqli('localhost', 'root', '');
            if (mysqli_errno($connection)) {
                $errors[] = 'Failed Connection';
            }
         
            $db = mysqli_select_db($connection, 'blog') or die('Error in database');
            mysqli_set_charset($connection, 'utf8');

            $query = mysqli_query($connection, 'SELECT * FROM posts WHERE id = '. $idTask);

            if (!$query) {
                $errors[] = 'Failed Query';
            }

            $row = $query->fetch_object();
           
            $task = new Task();
            $task->id = $row->id;
            $task->title = $row->title;
            $task->description = $row->description;
            $task->created = $row->created;

            if ($row->userId == $_SESSION['user_id']) {
                 header('Location: index.php?page=tasks&action=list');
            }
            if (count($errors) > 0) {
                return $errors;
            } else {
                return $task;
                mysqli_close($connection);
            }
        }
        return false;
    }

    public static function getTasks($userId) {
        //exit(var_dump($_SESSION['user_id']));
        $errors = array();
        $user_id = (int) $userId;
        
        $user_id = Validation::validateRequired($userId, 'User Id');

        if (in_array('error', $user_id)) {
            $errors = $user_id['data']; //ediniqt masiv
            //exit(var_dump($errors));
        } else {
            $connection = mysqli_connect('localhost', 'root', '');
          
            if (mysqli_errno($connection)) {
                printf("Connection failed", mysqli_connect_error());
                exit;
            }
            
            $db = mysqli_select_db($connection, 'blog') or die('Error in database');
            mysqli_set_charset($connection, 'utf8');
            
            $query = mysqli_query($connection, 'SELECT * FROM posts WHERE userId='. $userId);
             
            if (!$query) {
                $errors[] = 'Error in query'; //drugiqt masiv
            }
        }
        if (count($errors) > 0) {
            return $errors = array('status' => 'errorMessage', 'data' => $errors);
        } else {
            $arr = array();
            // $tasks = $query->fetch_object();
            while ($tasks = $query->fetch_object()) {
                array_push($arr, $tasks);
            }
            return $arr;
        }
        mysqli_close($connection);
    }

    
    public static function createTask($title, $description, $created) {

        $errors = array();
        
        $titleRequired = Validation::validateRequired($title, 'Title'); //empty
        $descriptionRequired = Validation::validateRequired($description, 'Description'); //empty
        $createdValid = Validation::isValidateDateTimeString($created);
        
        if (in_array('error', $titleRequired)) {
            $errors[] = $titleRequired['data'];
        }
        if (in_array('error', $descriptionRequired)) {
            $errors[] = $descriptionRequired['data'];
        }
        if (in_array('error', $createdValid)) {
            $errors[] = $createdValid['data'];
        }

        if (count($errors) > 0) {
            return $errors;
        } else {
            
            $task = new Task();
            $task->title = $title;
            $task->description = $description;
            $task->dueDate =  $created;
            
            $connection = mysqli_connect('localhost', 'root', '', 'blog');
            mysqli_set_charset($connection, 'utf8');
            $title = mysqli_real_escape_string($connection, $title);
            $description = mysqli_real_escape_string($connection, $description);
            $created = mysqli_real_escape_string($connection, $created);
            
            $query = mysqli_query($connection, 'INSERT INTO posts (title, description, created, userId) VALUES ("'.$title.'", "'.$description.'", "'.$created.'", "'.$_SESSION['user_id'].'")');
            
            if (!$query) {
                return $errors[] = 'Errors';
            }else{
                return $task;
            }
            
            mysqli_close($connection);
        }
        
    }

    
    public function updateTask($title, $description, $created){ //$_POST['title'], $_POST['description'], $_POST['created'], $_POST['dueDate'])//
        
        $errors = array();
        //Validation with data 
        $titleRequired = Validation::validateRequired($title, 'Title'); //empty
        $descriptionRequired = Validation::validateRequired($description, 'Description');//empty
        $dueDateRequired =  Validation::validateRequired($description, 'Due Date');
        $createdValid = Validation::isValidateDateTimeString($created);
    
        if (in_array('error', $titleRequired)) {
            $errors[] = $titleRequired['data'];
        }
         if (in_array('error', $descriptionRequired)) {
            $errors[] = $descriptionRequired['data'];
        }
        if (in_array('error', $dueDateRequired)) {
            $errors[] = $dueDateRequired['data'];
        }
        if (in_array('error', $createdValid)) {
            $errors[] = $createdValid['data'];
        }
        
        if (count($errors) > 0) {
            return $errors;
        }else{
            $this->id;
            $this->title = $title;
            $this->description = $description;
            $this->created = $created;
            $this->userId;
            
            $connection = mysqli_connect('localhost', 'root', '', 'blog');
            mysqli_set_charset($connection, 'utf8');
            
            $title = mysqli_real_escape_string($connection, $title);
            $description = mysqli_real_escape_string($connection, $description);
            $created = mysqli_real_escape_string($connection, $created);
             
            $query = mysqli_query($connection, 'UPDATE posts SET title = "'.$title.'", description = "'.$description.'", created = "'.$created.'"  WHERE id = '.$this->id);
           
            if (!$query) {
                return false;
            }
            return $this;
            mysqli_close($connection);
        }
        return false;
    }
    
    public static function deleteTask($idTask) {
        
        $errors = array();
        $connection = mysqli_connect('localhost', 'root', '', 'blog');
        mysqli_set_charset($connection, 'utf8');
        
        $id = Validation::validateRequired($idTask, 'Id Task');
        if (in_array('error', $id)) {
         $errors[] = $id['data'];   
        }
        
        if (count($errors) > 0) {
         return $errors;   
        }else{
            $query = mysqli_query($connection, "DELETE FROM posts WHERE id = $idTask");
            if (!$query) {
                return $errors[] = 'Error Query';
            }else{
                echo 'Ok';
            }
        }
        
        return false;
    }

}
