<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of User
 *
 * @author nhuen
 */
class User {

     private $id;
     public $username,
            $password,
            $email;
     
    public static function loginUser($email, $password) { // POST['username']. POST['password']
        
        //Connection with database : 
        $errors = array();
        
        $connection = new mysqli('localhost', 'root', '', 'blog');
        if (!$connection) {
           $errors[] = 'No connection with database';
        } else {
            $password = md5($password);
            $query = mysqli_query($connection, 'SELECT * FROM users WHERE email = "' . $email . '" AND password = "' . $password . '" LIMIT 1'); //object

            $rows = mysqli_fetch_object($query); //object
            
            $user = new User();
            $email = $user->email;
            $password = $user->password;
            
            if ($query->num_rows == 1) {
                $_SESSION['logged'] = true;
                $_SESSION['user_id'] = $rows->id;
                $_SESSION['username'] = $rows->email;
            } else {
                $errors[] = 'Wrong username or Password.Please try again';
            }
            
            if (count($errors) > 0) {
                return $errors;
            }else{
                return $user;
            }
        }
        
        mysqli_close($connection);
    }
    
    public static function registerUser($username, $email, $password, $confirmPass) {

        $errors = array();

        //Validation of username , $email , password, confirmPass
        $emailArr = Validation::validateEmail($email);
        $passwordArr = Validation::validatePassword($password, $confirmPass); //validation
        $usernameArr = Validation::validateRequired($username);

        if (in_array('error', $emailArr)) {
            $errors[] = $emailArr['data'];
        }
        if (in_array('error', $passwordArr)) {
            $errors[] = $passwordArr['data'];
        }
        if (in_array('error', $usernameArr)) {
            $errors[] = $usernameArr['data'];
        }

        $connection = mysqli_connect('localhost', 'root', '', 'blog');

        mysqli_set_charset($connection, 'utf8');
        $password = mysqli_real_escape_string($connection, $password);
        $confirmPass = mysqli_real_escape_string($connection, $confirmPass);
        $password = md5($password);

        //name or email already exist? 
        $query = mysqli_query($connection, 'SELECT id FROM `users` WHERE name = "' . $username . '" OR email = "' . $email . '" LIMIT 1');
        if (mysqli_num_rows($query) == 1) {
            $errors[] = array('Username exists');
        } else {
            $query = mysqli_query($connection, 'INSERT INTO `users` (name, email, password) VALUES ("' . $username . '", "' . $email . '","' . $password . '")');
            if (!$query) {
                $errors[] = array('Query Failed');
            }
            $user = new User();
            $user->username = $username;
            $user->email = $email;
            $user->password = $password;
        }
        
        if (count($errors) > 0) {
            return $errors;
        } else {
            return $user;
        }
          return false;
          mysqli_close($connection);
    }

     public static function updatePassword($email, $password, $newPassword, $confirmPassword) {
        // exit(var_dump($_SESSION));
       
        $errors = array();
        //Validation of data 
        $emailRequired = Validation::validateRequired($email, 'Email');
        $passRequired = Validation::validateRequired($password, 'Password');
        $newPassRequired = Validation::validateRequired($newPassword, 'New Password');
        $confirmPassRequired = Validation::validateRequired($confirmPassword, 'Confirm Password');
        
       
        $confirmPassArr = Validation::validatePassword($newPassword, $confirmPassword);
        $emailArr = Validation::validateEmail($email);
        
        if (in_array('error', $emailRequired)) {
            $errors[] = $emailRequired['data'];
        }
        
        if (in_array('error', $passRequired)) {
            $errors[] = $passRequired['data'];
        }
        
        if (in_array('error', $confirmPassRequired)) {
            $errors[] = $confirmPassRequired['data'];
        }
        if (in_array('error', $newPassRequired)) {
            $errors[] = $newPassRequired['data'];
        }

        if (in_array('error', $emailArr)) {
            $errors[] = $emailArr['data'];
        }
       
        if (in_array('error', $confirmPassArr)) {
            $errors[] = $confirmPassArr['data'];
        }

        $connection = mysqli_connect('localhost', 'root', '', 'blog');
        mysqli_set_charset($connection, 'utf8');
        
        $email = mysqli_real_escape_string($connection, $email);
        $password = mysqli_real_escape_string($connection, $password); // md5 - prevrushta vs simvoli v bukvi i cifri
        $newPassword = mysqli_real_escape_string($connection, $newPassword);
        $password = md5($password);
        $newPassword = md5($newPassword);
        
        if (count($errors) > 0) {
            return $errors;
        }else{
             
        $updated = new User();
        $updated->email = $email;
        $updated->password = $password;
        
        $query = mysqli_query($connection, 'UPDATE `users` SET password = "' . md5($newPassword) . '" WHERE email = "' . $email . '" AND password = "' . md5($password) . '"');
         //echo 'UPDATE `users` SET password = "' . $newPassword . '" WHERE  email = "' . $email . '" AND password = "' . $password . '"';
         //exit;
        return $updated;
        mysqli_close($connection);
        }
    }

    public static function logoutUser($userId) {
        session_destroy();
        header('Location: index.php');
        exit;
    }
}
