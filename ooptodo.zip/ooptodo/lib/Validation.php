<?php

class Validation {
    
    private static $codeStatus = array();
    //Title and description
    public static function validateRequired($field, $fieldName) {
        
        $errorMsg = array();
        if (!isset($field) || empty($field)) {
             $errorMsg[] = "$fieldName : Empty .Please try again";
        }else if (mb_strlen($field) < 1 || mb_strlen($field) >= 100) {
             $errorMsg[] = 'Too Short or long field!';
        }

        $field = trim($field);
        $field = stripslashes($field);
        $field = htmlspecialchars($field);
        //$field = mysql_real_escape_string($field);

        if (count($errorMsg) > 0) {
            return self::$codeStatus = array('status' => 'error', 'data' => $errorMsg);
        } else {
            return self::$codeStatus = array('status' => 'success');
        }
    }
    
    public static function validateEmail($email){
       
        $errorMsg = array();
        
        if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) { //prazen email - e ne validen email
            $errorMsg[] = "Your Email is not valid email address";
        } 
        
        $email = trim($email);
        $email = mysql_real_escape_string($email);
        
        if (count($errorMsg) > 0) {
            return self::$codeStatus = array('status' => 'error', 'data' => $errorMsg);
        }else{
            return self::$codeStatus = array('status'=> 'success');
        }
    }
    
    public static function validatePassword($password, $confirmPass) {

        $errorMsg = array();

        if (strlen($password) <= 3) {
            $errorMsg[] = "Your Password Must Contain At Least 3 Characters!";
//        } else if (empty($password) || !isset($password) || !isset($confirmPass)) {
//            $errorMsg[] = "Empty fields";
//        } else if (!preg_match("#[0-9]+#", $password)) {
//            $errorMsg[] = "Your Password Must Contain At Least 1 Number!";
//        } else if (!preg_match("#[A-Z]+#", $password)) {
//            $errorMsg[] = "Your Password Must Contain At Least 1 Capital Letter!";
//        } else if (!preg_match("#[a-z]+#", $password)) {
//            $errorMsg[] = "Your Password Must Contain At Least 1 Lowercase Letter!";
        } else if ($password != $confirmPass) {
            $errorMsg[] = "No matched passwords. Please try again!";
        }
        
        if (count($errorMsg) > 0) {
            return self::$codeStatus = array('status' => 'error', 'data' => $errorMsg);
        } else {
            return self::$codeStatus = array('status' => 'success');
        }
    }
    
    //we dont have priority but 
    public static function validatePriority($priority, $priorityArr){ 
        
        $errorMsg = array();
        
        if (!array_key_exists($priority, $priorityArr)) {
            $errorMsg[] = 'The key does not exist!. Please try again';
        }
        if(count($errorMsg) > 0){
             return self::$codeStatus = array('status' => 'error', 'data' => $errorMsg);
        }else{
            return self::$codeStatus = array('status' => 'success');
        }
    }
    
    public static function isValidateDateTimeString($datetime, $format = 'Y-m-d H:i:s') { //$_POST['created']) 
        
        $errorMsg = array();
        //var_dump(DateTime::createFromFormat($format, $datetime));
        //exit;
        if (DateTime::createFromFormat($format, $datetime) === FALSE) {
            $errorMsg[] = 'Date or time is invalid. Please Try again!';
        }
        if (count($errorMsg) > 0) {
            return self::$codeStatus = array('status' => 'error', 'data' => $errorMsg);
        } else {
            return self::$codeStatus = array('status' => 'success');
        }
    }

}
