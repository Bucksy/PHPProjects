<?php
include './lib/User.php';
?>
<form method="POST" >
    First name:<br>
    <input type="text" name="username"/>
    <br>
    Password:<br>
    <input type="password" name="password"/>
    <br>
    <input type="submit" value="Log in">
</form> 

<?php
 if (isset($_SESSION['logged'])) {
        header('Location: getPosts.php');
    }
    $user = User::loginUser($_POST['username'], $_POST['password']);