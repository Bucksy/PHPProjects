<?php
include './data/priorities.php';
//echo '<pre>' . print_r($task, true) . '</pre>';
?>
<form action="index.php?page=tasks&action=<?php echo isset($task) ? 'update&id='. $task->id : 'create'?>" method="POST">
    <table>
        <tr>
            <td>Name: </td>
            <td><input type="text" name="title" value="<?php echo isset($task) ? $task->title : '' ?>"/></td>
        </tr>
        <tr>
            <td>Description: </td>
            <td><textarea name="description" placeholder="<?php echo isset($task) ? $task->description : '' ?>"></textarea></td>
        </tr>
<!--        <tr>
            <td>Priority: </td>
            <td>
                <select name="priority">
                   <?php
//                   foreach ($priorities as $key=>$priority) {
//                       echo '<option value='.$key.'>'.$priority.'</option>';
//                   }
                   ?>          
                </select>
            </td>
        </tr>-->
        <tr>
            <td>Created Date: </td>
            <td><input type="text" name="created" value="<?php echo isset($task) ? $task->created : '' ?>" /></td>
        </tr>
        <tr>
            <td colspan="2" ><input type="submit" value="<?php echo isset($task) ? 'Update' : 'Create'?>" name="<?php echo isset($task) ? 'updateTask' : 'createTask'  ?>"/></td>
        </tr>
    </table>
</form>
<?php
                   
