<form id='register' action="" method="POST"
      accept-charset='UTF-8'>
    <fieldset >
        <legend>Register</legend>
        <label for='name' >Your Full Name*: </label>
        <input type='text' name='username' id='name' maxlength="50" /><br/>
        <label for='email' >Email Address*:</label>
        <input type='text' name='email' id='email' maxlength="50" /><br/>

        <label for='password' >Password*:</label>
        <input type='password' name='password' id='password' maxlength="50" /><br/>

        <label for='password' >Confirm Password*:</label>
        <input type='password' name='confirmPassword' id='passwordConfirm' maxlength="50" /><br/>
        <input type='submit' name='registerSubmit' value='Register' />
    </fieldset>
</form>