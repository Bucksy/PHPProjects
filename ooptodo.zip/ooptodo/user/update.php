<form method="POST" action="">
    Email: <input type="email" name="email"/><br/>
    Password: <input type="password" name="password"/><br/>
    New Password: <input type="password" name="newPassword"/><br/>
    Confirm Password: <input type="password" name="confirmPassword"/><br/>
    <input type="submit" name="passwordSubmit" value="Update"/>
</form>